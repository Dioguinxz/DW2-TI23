import './titulo.css'
import Botao from '../Botao/botao'
export default function Titulo() {
    return (
      <div className='header'>
        <h3>Meu Chat</h3>
        <Botao></Botao>
      </div>
    )
  }
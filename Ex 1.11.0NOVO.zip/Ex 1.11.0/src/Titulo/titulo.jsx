

function Titulo() {
    return (
        <>
    <div class="header">
            <h3>Meu Chat</h3>
          </div>
        </>
      )
}

export default Titulo
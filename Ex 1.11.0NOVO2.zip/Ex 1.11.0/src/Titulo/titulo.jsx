import Button from '../Button/button'
import './titulo.css'

function Titulo() {
  return (
    <>
      <div class="header">
        <h3>Meu Chat</h3>
        <Button></Button>
      </div>
    </>
  )
}

export default Titulo